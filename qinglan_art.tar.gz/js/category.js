function closeAll() {
	document.getElementById("instrument").setAttribute("class","collapse nav nav-pills sub-categor");
	document.getElementById("vocal").setAttribute("class","collapse nav nav-pills sub-categor");
	document.getElementById("drawing").setAttribute("class","collapse nav nav-pills sub-categor");
	document.getElementById("calligraphy").setAttribute("class","collapse nav nav-pills sub-categor");
	document.getElementById("chess").setAttribute("class","collapse nav nav-pills sub-categor");

}